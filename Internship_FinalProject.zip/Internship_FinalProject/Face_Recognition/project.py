import cv2
from ubidots import ApiClient
FC=cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
cap=cv2.VideoCapture(0)
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read("training.yml")
id=0
font=cv2.FONT_HERSHEY_SIMPLEX
api=ApiClient(token='BBFF-tA40VhMp9XLwX5LKtrsKu1uWL227gA')
var=api.get_variable('632d31cf28e16133329f3f17')
while(1):
    ret,img=cap.read()
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces=FC.detectMultiScale(gray,1.3,5)
    for(x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
        id,conf=recognizer.predict(gray[y:y+h,x:x+w])
        print("confidence:",conf)
        cv2.imshow('image',img)
        e1=15767898741
        e2=840067713710
        e3=77922639525
        e4=525927809076
        e5=800014237457
        w=0
        if(id==1 and conf<65):
            print("Manoj")
            response=var.save_value({"value":e1,"context":{"key":"Manoj"}})
        elif(id==2 and conf<65):
            print("Bharath")
            response=var.save_value({"value":e2,"context":{"key":"Bharath"}})
        elif(id==3 and conf<65):
            print("Tejas")
            response=var.save_value({"value":e3,"context":{"key":"Tejas"}})
        elif(id==4 and conf<65):
            print("Spoorthi")
            response=var.save_value({"value":e4,"context":{"key":"Spoorthi"}})
        elif(id==5 and conf<65):
            print("Sukruth")
            response=var.save_value({"value":e5})
        else:
            print("Unknown")
            response=var.save_value({"value":w})
    if cv2.waitKey(1)==ord('q'):
        break
cap.release()
cv2.destroyAllWindows()

        