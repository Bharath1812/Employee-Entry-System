import os
import numpy as np
import cv2
from PIL import Image
recognizer = cv2.face.LBPHFaceRecognizer_create()
path="dataset/"
def getImagewithID(path):
    imagePath=[os.path.join(path,f) for f in os.listdir(path)]
    faces=[]
    IDs=[]
    for image in imagePath:
        facesImage=Image.open(image).convert('L')
        faceNP=np.array(facesImage,'uint8')
        print(faceNP)
        ID=int(os.path.split(image)[-1].split(".")[1])
        print(ID)
        faces.append(faceNP)
        IDs.append(ID)
        cv2.imshow("Adding faces for training",faceNP)
        cv2.waitKey(10)
    return np.array(IDs),faces
Ids,faces=getImagewithID(path)
recognizer.train(faces,Ids)
recognizer.save("training.yml")
cv2.destroyAllWindows()