import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BOARD)
from mfrc522 import SimpleMFRC522
reader=SimpleMFRC522()
try:
  id,text=reader.read()
  print(id)
  print(text)
finally:
 GPIO.cleanup()